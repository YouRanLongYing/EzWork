﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UBIQ.Framework.Biz;
using $saferootprojectname$.IBiz;
using $saferootprojectname$.Dto.Entity;

namespace $rootnamespace$
{
    /// <summary>
    /// clrversion:$clrversion$
    /// Guid:$guid1$
    /// itemname:$itemname$
    /// machinename:$machinename$
    /// registeredorganization:$registeredorganization$
    /// projname:$projname$
    /// userdomain:$userdomain$
    /// username:$username$
    /// time:$time$
    /// company:$company$
    /// </summary>
    public class $safeitemname$ : DefaultBiz, IDemoBiz
    {
        public Framework.IBiz.BizResult<Demo> TestFunction(Demo dto)
        {
            return new Framework.IBiz.BizResult<Demo>(true, new Demo
            {
                Key = "verson",
                Value = "v2.0"

            });
        }
    }
}
