﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UBIQ.Framework.Controllers.Library;
using $saferootprojectname$.IBiz;
using System.Web.Mvc;

namespace $rootnamespace$
{
    /// <summary>
    /// clrversion:$clrversion$
    /// Guid:$guid1$
    /// itemname:$itemname$
    /// machinename:$machinename$
    /// registeredorganization:$registeredorganization$
    /// projname:$projname$
    /// userdomain:$userdomain$
    /// username:$username$
    /// time:$time$
    /// company:$company$
    /// </summary>
    public class $safeitemname$: DefaultController<IDemoBiz>
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
