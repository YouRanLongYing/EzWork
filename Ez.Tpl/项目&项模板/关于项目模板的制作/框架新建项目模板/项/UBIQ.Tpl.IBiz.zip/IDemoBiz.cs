﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UBIQ.Framework.IBiz;
using $saferootprojectname$.Dto.Entity;
namespace $rootnamespace$
{
    /// <summary>
    /// clrversion:$clrversion$
    /// Guid:$guid1$
    /// itemname:$itemname$
    /// machinename:$machinename$
    /// registeredorganization:$registeredorganization$
    /// projname:$projname$
    /// userdomain:$userdomain$
    /// username:$username$
    /// time:$time$
    /// company:$company$
    /// </summary>
    public interface $safeitemname$:IDefaultBiz
    {
        BizResult<Demo> TestFunction(Demo dto);
    }
}
